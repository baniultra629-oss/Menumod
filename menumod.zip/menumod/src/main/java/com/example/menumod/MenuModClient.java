package com.example.menumod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class MenuModClient implements ClientModInitializer {
	public static final String MOD_ID = "menumod";

	private static KeyBinding openMenuKey;
	private static KeyBinding zoomKey;

	/** FOV игрока до зума, чтобы вернуть его обратно. */
	private static Integer originalFov = null;

	@Override
	public void onInitializeClient() {
		openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.menumod.open",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_R,
				"category.menumod"
		));

		zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.menumod.zoom",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_C,
				"category.menumod"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openMenuKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new MenuScreen());
				}
			}
			updateZoom(client);
		});

		// Если игру закрыли во время зума — вернуть обычный FOV
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> restoreFov(client));

		HudRenderCallback.EVENT.register((context, tickCounter) -> {
			MinecraftClient client = MinecraftClient.getInstance();
			if (!MenuState.showCoords || client.player == null || client.options.hudHidden) {
				return;
			}

			String coords = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
					client.player.getX(), client.player.getY(), client.player.getZ());
			Text facing = Text.translatable("hud.menumod.facing", client.player.getHorizontalFacing().asString());

			context.drawTextWithShadow(client.textRenderer, coords, 6, 6, 0xFFFFFF);
			context.drawTextWithShadow(client.textRenderer, facing, 6, 18, 0xFFFFFF);
		});
	}

	private static void updateZoom(MinecraftClient client) {
		if (client.options == null) {
			return;
		}

		boolean zooming = client.player != null && (zoomKey.isPressed() || MenuState.zoomToggled);
		var fov = client.options.getFov();

		if (zooming) {
			if (originalFov == null) {
				originalFov = fov.getValue();
			}
			if (fov.getValue().intValue() != MenuState.zoomFov) {
				fov.setValue(MenuState.zoomFov);
			}
		} else {
			restoreFov(client);
		}
	}

	private static void restoreFov(MinecraftClient client) {
		if (originalFov != null && client.options != null) {
			client.options.getFov().setValue(originalFov);
			originalFov = null;
		}
	}
}
