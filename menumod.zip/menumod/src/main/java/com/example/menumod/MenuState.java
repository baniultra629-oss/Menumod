package com.example.menumod;

/** Общие настройки мода (живут, пока запущена игра). */
public final class MenuState {
	public static boolean showCoords = true;
	public static boolean zoomToggled = false;
	/** FOV при зуме. Меньше = сильнее приближение. Минимум в игре — 30. */
	public static int zoomFov = 30;

	private MenuState() {}
}
