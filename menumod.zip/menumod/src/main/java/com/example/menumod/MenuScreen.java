package com.example.menumod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
	private static final int BUTTON_WIDTH = 200;
	private static final int BUTTON_HEIGHT = 20;
	private static final int GAP = 6;

	private boolean toggled = false;
	private int clicks = 0;

	private ButtonWidget toggleButton;
	private ButtonWidget counterButton;

	public MenuScreen() {
		super(Text.translatable("screen.menumod.title"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - BUTTON_WIDTH / 2;
		int y = this.height / 2 - 55;

		// 1. Переключатель ON/OFF
		toggleButton = ButtonWidget.builder(toggleText(), button -> {
			toggled = !toggled;
			button.setMessage(toggleText());
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build();
		this.addDrawableChild(toggleButton);

		// 2. Счётчик нажатий
		y += BUTTON_HEIGHT + GAP;
		counterButton = ButtonWidget.builder(counterText(), button -> {
			clicks++;
			button.setMessage(counterText());
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build();
		this.addDrawableChild(counterButton);

		// 3. Сообщение в чат
		y += BUTTON_HEIGHT + GAP;
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.menumod.say_hello"), button -> {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client.player != null) {
				client.player.sendMessage(Text.translatable("screen.menumod.hello_message"), false);
			}
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());

		// 4. Закрыть
		y += BUTTON_HEIGHT + GAP + 10;
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.menumod.close"), button -> this.close())
				.dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());
	}

	private Text toggleText() {
		return Text.translatable("screen.menumod.toggle",
				Text.translatable(toggled ? "screen.menumod.on" : "screen.menumod.off"));
	}

	private Text counterText() {
		return Text.translatable("screen.menumod.counter", clicks);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 80, 0xFFFFFF);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
