package com.example.menumod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
	private static final int BUTTON_WIDTH = 200;
	private static final int BUTTON_HEIGHT = 20;
	private static final int GAP = 6;

	/** Варианты силы зума (FOV). Минимум в игре — 30. */
	private static final int[] ZOOM_LEVELS = {50, 40, 30};

	public MenuScreen() {
		super(Text.translatable("screen.menumod.title"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - BUTTON_WIDTH / 2;
		int y = this.height / 2 - 45;

		// 1. Координаты на экране
		this.addDrawableChild(ButtonWidget.builder(coordsText(), button -> {
			MenuState.showCoords = !MenuState.showCoords;
			button.setMessage(coordsText());
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());

		// 2. Зум вкл/выкл
		y += BUTTON_HEIGHT + GAP;
		this.addDrawableChild(ButtonWidget.builder(zoomText(), button -> {
			MenuState.zoomToggled = !MenuState.zoomToggled;
			button.setMessage(zoomText());
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());

		// 3. Сила зума
		y += BUTTON_HEIGHT + GAP;
		this.addDrawableChild(ButtonWidget.builder(zoomLevelText(), button -> {
			MenuState.zoomFov = nextZoomLevel(MenuState.zoomFov);
			button.setMessage(zoomLevelText());
		}).dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());

		// 4. Закрыть
		y += BUTTON_HEIGHT + GAP + 10;
		this.addDrawableChild(ButtonWidget.builder(Text.translatable("screen.menumod.close"), button -> this.close())
				.dimensions(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).build());
	}

	private static Text onOff(boolean value) {
		return Text.translatable(value ? "screen.menumod.on" : "screen.menumod.off");
	}

	private static Text coordsText() {
		return Text.translatable("screen.menumod.coords", onOff(MenuState.showCoords));
	}

	private static Text zoomText() {
		return Text.translatable("screen.menumod.zoom", onOff(MenuState.zoomToggled));
	}

	private static Text zoomLevelText() {
		return Text.translatable("screen.menumod.zoom_level", MenuState.zoomFov);
	}

	private static int nextZoomLevel(int current) {
		for (int i = 0; i < ZOOM_LEVELS.length; i++) {
			if (ZOOM_LEVELS[i] == current) {
				return ZOOM_LEVELS[(i + 1) % ZOOM_LEVELS.length];
			}
		}
		return ZOOM_LEVELS[0];
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 70, 0xFFFFFF);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
