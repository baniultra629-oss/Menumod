# Menu Mod (Fabric 1.21.4)

Клиентский мод с GUI-меню. Открывается клавишей **R** (меняется в Настройки → Управление → Menu Mod).

В меню: переключатель ВКЛ/ВЫКЛ, счётчик нажатий, кнопка «Поздороваться в чате», кнопка «Закрыть».

## Сборка

Нужна Java 21 и Gradle (или Gradle Wrapper).

```
gradle build
```

Готовый мод: `build/libs/menumod-1.0.0.jar` (файл `-sources` не нужен).
Положи jar в папку `mods` вместе с Fabric Loader и Fabric API для 1.21.4.

## Запуск из среды разработки

```
gradle runClient
```

## Где что менять

- `MenuScreen.java` — кнопки и логика меню
- `MenuModClient.java` — регистрация клавиши
- `assets/menumod/lang/*.json` — тексты (английский и русский)
